AMAZON INDIA DASHBOARD — SAPPHIRE IQ
Built from the supplied Amazon Sales Data India.xlsx (10,000 rows, 13 columns) and the supplied requirements PDF.

MAIN FILE: Amazon_India_Dashboard_Final.xlsx
DASHBOARD VIEW: Amazon_India_Dashboard.html
DAX: Power_BI_DAX_Measures.txt

The Excel workbook contains Dashboard, Sales_Data, Monthly_Trend, Category_Performance, Top_10_Products, Order_Status, Payment, Fulfillment and State_Performance sheets.

No synthetic records were used.
